# vim
vim配置

### 简易安装方法：

打开终端，执行下面的命令就自动安装好了：

`wget -qO- https://raw.github.com/nickdecodes/vim/master/install.sh | sh -x`

### 或者自己手动安装：

直接查看[install.sh](install.sh)即可
