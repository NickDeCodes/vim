# ftdetect
文件启动检测